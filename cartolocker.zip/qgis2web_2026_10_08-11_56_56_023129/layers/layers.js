var wms_layers = [];


        var lyr_GoogleHybrid_0 = new ol.layer.Tile({
            'title': 'Google Hybrid',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });

        var lyr_GoogleRoad_1 = new ol.layer.Tile({
            'title': 'Google Road',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'
            })
        });

var vectorTileUrl_LOCKERSMondialRelay_2 = 'layers/LOCKERSMondialRelay_2-pbf/{z}/{x}/{y}.pbf';
var vectorTileSource_LOCKERSMondialRelay_2 = new ol.source.VectorTile({
    format: new ol.format.MVT({
            featureClass: ol.Feature,
            layerName: '_mvtLayer_'
        }),
    tileSize: 256,
    cacheSize: 512,
    minZoom: 3,
    maxZoom: 4,
    url: vectorTileUrl_LOCKERSMondialRelay_2,
    attributions: ' '
});
var lyr_LOCKERSMondialRelay_2 = new ol.layer.VectorTile({
    declutter: false,
    source: vectorTileSource_LOCKERSMondialRelay_2,
    sourceType: 'pbf',
    popuplayertitle: 'LOCKERS Mondial Relay',
    extent: ol.proj.transformExtent([-283572.26522053365, 5833736.713473207, 84769.68091958702, 6187645.909789986], 'EPSG:3857', 'EPSG:3857'),
    interactive: true,
    style: style_LOCKERSMondialRelay_2,
    title: '<img src="styles/legend/LOCKERSMondialRelay_2.png" /> LOCKERS Mondial Relay'
});


var vectorTileUrl_ConsignePULaPoste_3 = 'layers/ConsignePULaPoste_3-pbf/{z}/{x}/{y}.pbf';
var vectorTileSource_ConsignePULaPoste_3 = new ol.source.VectorTile({
    format: new ol.format.MVT({
            featureClass: ol.Feature,
            layerName: '_mvtLayer_'
        }),
    tileSize: 256,
    cacheSize: 512,
    minZoom: 3,
    maxZoom: 4,
    url: vectorTileUrl_ConsignePULaPoste_3,
    attributions: ' '
});
var lyr_ConsignePULaPoste_3 = new ol.layer.VectorTile({
    declutter: false,
    source: vectorTileSource_ConsignePULaPoste_3,
    sourceType: 'pbf',
    popuplayertitle: 'Consigne PU La Poste',
    extent: ol.proj.transformExtent([-279761.7990506799, 5833594.517503428, 73674.80123069383, 6186257.79945171], 'EPSG:3857', 'EPSG:3857'),
    interactive: true,
    style: style_ConsignePULaPoste_3,
    title: '<img src="styles/legend/ConsignePULaPoste_3.png" /> Consigne PU La Poste'
});

var format_FuturPUlaposte_4 = new ol.format.GeoJSON();
var features_FuturPUlaposte_4 = format_FuturPUlaposte_4.readFeatures(json_FuturPUlaposte_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_FuturPUlaposte_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_FuturPUlaposte_4.addFeatures(features_FuturPUlaposte_4);
var lyr_FuturPUlaposte_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_FuturPUlaposte_4, 
                style: style_FuturPUlaposte_4,
                popuplayertitle: 'Futur PU la poste',
                interactive: true,
                title: '<img src="styles/legend/FuturPUlaposte_4.png" /> Futur PU la poste'
            });

var vectorTileUrl_VintedGO_5 = 'layers/VintedGO_5-pbf/{z}/{x}/{y}.pbf';
var vectorTileSource_VintedGO_5 = new ol.source.VectorTile({
    format: new ol.format.MVT({
            featureClass: ol.Feature,
            layerName: '_mvtLayer_'
        }),
    tileSize: 256,
    cacheSize: 512,
    minZoom: 3,
    maxZoom: 4,
    url: vectorTileUrl_VintedGO_5,
    attributions: ' '
});
var lyr_VintedGO_5 = new ol.layer.VectorTile({
    declutter: false,
    source: vectorTileSource_VintedGO_5,
    sourceType: 'pbf',
    popuplayertitle: 'VintedGO',
    extent: ol.proj.transformExtent([-262140.4691236096, 5841533.771896412, 81942.21038123422, 6181540.150148334], 'EPSG:3857', 'EPSG:3857'),
    interactive: true,
    style: style_VintedGO_5,
    title: '<img src="styles/legend/VintedGO_5.png" /> VintedGO'
});


var vectorTileUrl_amazon_lockers_pays_de_la_loire_2023_2024_6 = 'layers/amazon_lockers_pays_de_la_loire_2023_2024_6-pbf/{z}/{x}/{y}.pbf';
var vectorTileSource_amazon_lockers_pays_de_la_loire_2023_2024_6 = new ol.source.VectorTile({
    format: new ol.format.MVT({
            featureClass: ol.Feature,
            layerName: '_mvtLayer_'
        }),
    tileSize: 256,
    cacheSize: 512,
    minZoom: 3,
    maxZoom: 4,
    url: vectorTileUrl_amazon_lockers_pays_de_la_loire_2023_2024_6,
    attributions: ' '
});
var lyr_amazon_lockers_pays_de_la_loire_2023_2024_6 = new ol.layer.VectorTile({
    declutter: false,
    source: vectorTileSource_amazon_lockers_pays_de_la_loire_2023_2024_6,
    sourceType: 'pbf',
    popuplayertitle: 'amazon_lockers_pays_de_la_loire_2023_2024',
    extent: ol.proj.transformExtent([-265995.6968607113, 5848569.126381897, 73958.2206542536, 6184155.241394026], 'EPSG:3857', 'EPSG:3857'),
    interactive: true,
    style: style_amazon_lockers_pays_de_la_loire_2023_2024_6,
    title: '<img src="styles/legend/amazon_lockers_pays_de_la_loire_2023_2024_6.png" /> amazon_lockers_pays_de_la_loire_2023_2024'
});


lyr_GoogleHybrid_0.setVisible(true);lyr_GoogleRoad_1.setVisible(true);lyr_LOCKERSMondialRelay_2.setVisible(true);lyr_ConsignePULaPoste_3.setVisible(true);lyr_FuturPUlaposte_4.setVisible(true);lyr_VintedGO_5.setVisible(true);lyr_amazon_lockers_pays_de_la_loire_2023_2024_6.setVisible(true);
var layersList = [lyr_GoogleHybrid_0,lyr_GoogleRoad_1,lyr_LOCKERSMondialRelay_2,lyr_ConsignePULaPoste_3,lyr_FuturPUlaposte_4,lyr_VintedGO_5,lyr_amazon_lockers_pays_de_la_loire_2023_2024_6];
lyr_LOCKERSMondialRelay_2.set('fieldAliases', {'CodePostalRecherche': 'CodePostalRecherche', 'PositionDansLaReponse': 'PositionDansLaReponse', 'NumeroMondialRelay': 'NumeroMondialRelay', 'CodeAgence': 'CodeAgence', 'CodeNature': 'CodeNature', 'NomLocker': 'NomLocker', 'ComplementNom': 'ComplementNom', 'AdresseLigne1': 'AdresseLigne1', 'AdresseLigne2': 'AdresseLigne2', 'CodePostal': 'CodePostal', 'Ville': 'Ville', 'Pays': 'Pays', 'Latitude': 'Latitude', 'Longitude': 'Longitude', 'EstPIS': 'EstPIS', 'Services': 'Services', });
lyr_ConsignePULaPoste_3.set('fieldAliases', {'Libellé': 'Libellé', 'Adresse': 'Adresse', 'Code Postal': 'Code Postal', 'Ville': 'Ville', 'PR': 'PR', 'longitude': 'longitude', 'latitude': 'latitude', });
lyr_FuturPUlaposte_4.set('fieldAliases', {'Nom relais': 'Nom relais', 'adresse': 'adresse', 'code posta': 'code posta', 'Ville': 'Ville', 'Date de pa': 'Date de pa', 'Date de fo': 'Date de fo', 'DEX': 'DEX', 'Site livra': 'Site livra', 'ID La Post': 'ID La Post', 'longitude': 'longitude', 'latitude': 'latitude', });
lyr_VintedGO_5.set('fieldAliases', {'id': 'id', 'nom': 'nom', 'adresse': 'adresse', 'ville': 'ville', 'cp': 'cp', 'lat': 'lat', 'lng': 'lng', });
lyr_amazon_lockers_pays_de_la_loire_2023_2024_6.set('fieldAliases', {'ID': 'ID', 'Nom': 'Nom', 'Type': 'Type', 'Commune': 'Commune', 'Code postal': 'Code postal', 'Département': 'Département', 'Nom département': 'Nom département', 'Adresse': 'Adresse', 'Créé le': 'Créé le', 'Mis à jour le': 'Mis à jour le', 'Statut': 'Statut', 'Source': 'Source', });
lyr_LOCKERSMondialRelay_2.set('fieldImages', {'CodePostalRecherche': 'Range', 'PositionDansLaReponse': 'Range', 'NumeroMondialRelay': 'Range', 'CodeAgence': 'Range', 'CodeNature': 'TextEdit', 'NomLocker': 'TextEdit', 'ComplementNom': 'TextEdit', 'AdresseLigne1': 'TextEdit', 'AdresseLigne2': 'TextEdit', 'CodePostal': 'Range', 'Ville': 'TextEdit', 'Pays': 'TextEdit', 'Latitude': 'TextEdit', 'Longitude': 'TextEdit', 'EstPIS': 'CheckBox', 'Services': 'TextEdit', });
lyr_ConsignePULaPoste_3.set('fieldImages', {'Libellé': 'TextEdit', 'Adresse': 'TextEdit', 'Code Postal': 'Range', 'Ville': 'TextEdit', 'PR': 'Range', 'longitude': 'TextEdit', 'latitude': 'TextEdit', });
lyr_FuturPUlaposte_4.set('fieldImages', {'Nom relais': 'TextEdit', 'adresse': 'TextEdit', 'code posta': 'TextEdit', 'Ville': 'TextEdit', 'Date de pa': 'TextEdit', 'Date de fo': 'TextEdit', 'DEX': 'TextEdit', 'Site livra': 'TextEdit', 'ID La Post': 'TextEdit', 'longitude': 'TextEdit', 'latitude': 'TextEdit', });
lyr_VintedGO_5.set('fieldImages', {'id': 'Range', 'nom': 'TextEdit', 'adresse': 'TextEdit', 'ville': 'TextEdit', 'cp': 'Range', 'lat': 'TextEdit', 'lng': 'TextEdit', });
lyr_amazon_lockers_pays_de_la_loire_2023_2024_6.set('fieldImages', {'ID': 'TextEdit', 'Nom': 'TextEdit', 'Type': 'TextEdit', 'Commune': 'TextEdit', 'Code postal': 'TextEdit', 'Département': 'TextEdit', 'Nom département': 'TextEdit', 'Adresse': 'TextEdit', 'Créé le': 'DateTime', 'Mis à jour le': 'DateTime', 'Statut': 'Range', 'Source': 'TextEdit', });
lyr_LOCKERSMondialRelay_2.set('fieldLabels', {'CodePostalRecherche': 'no label', 'PositionDansLaReponse': 'no label', 'NumeroMondialRelay': 'no label', 'CodeAgence': 'no label', 'CodeNature': 'no label', 'NomLocker': 'no label', 'ComplementNom': 'no label', 'AdresseLigne1': 'no label', 'AdresseLigne2': 'no label', 'CodePostal': 'no label', 'Ville': 'no label', 'Pays': 'no label', 'Latitude': 'no label', 'Longitude': 'no label', 'EstPIS': 'no label', 'Services': 'no label', });
lyr_ConsignePULaPoste_3.set('fieldLabels', {'Libellé': 'no label', 'Adresse': 'no label', 'Code Postal': 'no label', 'Ville': 'no label', 'PR': 'no label', 'longitude': 'no label', 'latitude': 'no label', });
lyr_FuturPUlaposte_4.set('fieldLabels', {'Nom relais': 'no label', 'adresse': 'no label', 'code posta': 'no label', 'Ville': 'no label', 'Date de pa': 'no label', 'Date de fo': 'no label', 'DEX': 'no label', 'Site livra': 'no label', 'ID La Post': 'no label', 'longitude': 'no label', 'latitude': 'no label', });
lyr_VintedGO_5.set('fieldLabels', {'id': 'no label', 'nom': 'no label', 'adresse': 'no label', 'ville': 'no label', 'cp': 'no label', 'lat': 'no label', 'lng': 'no label', });
lyr_amazon_lockers_pays_de_la_loire_2023_2024_6.set('fieldLabels', {'ID': 'no label', 'Nom': 'no label', 'Type': 'no label', 'Commune': 'no label', 'Code postal': 'no label', 'Département': 'no label', 'Nom département': 'no label', 'Adresse': 'no label', 'Créé le': 'no label', 'Mis à jour le': 'no label', 'Statut': 'no label', 'Source': 'no label', });
lyr_amazon_lockers_pays_de_la_loire_2023_2024_6.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});